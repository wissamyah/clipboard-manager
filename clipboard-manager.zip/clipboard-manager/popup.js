document.addEventListener('DOMContentLoaded', () => {
  const listElement = document.getElementById('clipboard-list');
  const saveButton = document.getElementById('save-clipboard');
  const clearButton = document.getElementById('clear-clipboard');
  const exportButton = document.getElementById('export-clipboard');
  const searchInput = document.getElementById('search-input');
  const filterDropdown = document.getElementById('filter-dropdown');

  let clipboardHistory = [];

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 3000);
  }

  function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, 99999);
    document.execCommand('copy');
    document.body.removeChild(textarea);
    showToast('Text copied to clipboard!');
  }

  function refreshClipboardHistory(history) {
    console.log('Refreshing clipboard history display');
    listElement.innerHTML = '';

    const searchText = searchInput.value.toLowerCase();
    const filterValue = filterDropdown.value;

    if (history.length === 0) {
      const emptyMessage = document.createElement('li');
      emptyMessage.textContent = "No Clipboard History Saved.";
      listElement.appendChild(emptyMessage);
      return;
    }

    const filteredHistory = history
      .filter(item => {
        const textMatches = item.text.toLowerCase().includes(searchText);
        if (filterValue === 'favorites') {
          return item.favorite && textMatches;
        }
        return textMatches;
      });

    if (filterValue === 'favorites' && filteredHistory.length === 0) {
      const emptyMessage = document.createElement('li');
      emptyMessage.textContent = "No Clipboard Added to your Favorites.";
      listElement.appendChild(emptyMessage);
      return;
    }

    filteredHistory
      .sort((a, b) => {
        if (filterValue === 'recent') {
          return b.timestamp - a.timestamp;
        } else if (filterValue === 'oldest') {
          return a.timestamp - b.timestamp;
        }
        return 0;
      })
      .forEach(item => {
        const listItem = document.createElement('li');
        listItem.classList.add('clipboard-item');

        const textContainer = document.createElement('span');
        textContainer.classList.add('text-container');
        textContainer.textContent = item.text;
        textContainer.addEventListener('click', () => copyToClipboard(item.text));

        listItem.appendChild(textContainer);

        const timestamp = new Date(item.timestamp).toLocaleString('en-US', {
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        });
        const timestampSpan = document.createElement('span');
        timestampSpan.textContent = `[${timestamp}]`;
        timestampSpan.classList.add('timestamp');
        listItem.appendChild(timestampSpan);

        const favoriteIconContainer = document.createElement('div');
        favoriteIconContainer.classList.add('tooltip');

        const favoriteIcon = document.createElement('img');
        favoriteIcon.src = item.favorite ? 'icon-favorite-filled.png' : 'icon-favorite.png';
        favoriteIcon.alt = 'Favorite';
        favoriteIcon.classList.add('favorite-icon');
        favoriteIcon.addEventListener('click', event => {
          event.preventDefault();
          toggleFavorite(item.timestamp);
        });
        favoriteIconContainer.appendChild(favoriteIcon);

        const favoriteTooltip = document.createElement('span');
        favoriteTooltip.classList.add('tooltiptext');
        favoriteTooltip.textContent = 'Favorite';
        favoriteIconContainer.appendChild(favoriteTooltip);

        listItem.appendChild(favoriteIconContainer);

        const deleteIconContainer = document.createElement('div');
        deleteIconContainer.classList.add('tooltip');

        const deleteIcon = document.createElement('img');
        deleteIcon.src = 'icon-delete-24.png';
        deleteIcon.alt = 'Delete';
        deleteIcon.classList.add('delete-icon');
        deleteIcon.addEventListener('click', event => {
          event.preventDefault();
          deleteItem(item.timestamp);
        });
        deleteIconContainer.appendChild(deleteIcon);

        const deleteTooltip = document.createElement('span');
        deleteTooltip.classList.add('tooltiptext');
        deleteTooltip.textContent = 'Delete';
        deleteIconContainer.appendChild(deleteTooltip);

        listItem.appendChild(deleteIconContainer);

        listElement.appendChild(listItem);
      });
  }

  function getClipboardHistory() {
    chrome.storage.local.get(['clipboardHistory'], result => {
      if (chrome.runtime.lastError) {
        console.error('Error retrieving clipboard history:', chrome.runtime.lastError);
        return;
      }
      clipboardHistory = result.clipboardHistory || [];
      refreshClipboardHistory(clipboardHistory);
    });
  }

  getClipboardHistory();

  saveButton.addEventListener('click', saveClipboard);
  clearButton.addEventListener('click', clearClipboard);
  exportButton.addEventListener('click', exportClipboard);
  searchInput.addEventListener('input', () => refreshClipboardHistory(clipboardHistory));
  filterDropdown.addEventListener('change', () => refreshClipboardHistory(clipboardHistory));

  function saveClipboard() {
    navigator.clipboard.readText()
      .then(text => {
        if (text) {
          const newItem = { text: text, timestamp: Date.now(), favorite: false };
          clipboardHistory.push(newItem);
          chrome.storage.local.set({ clipboardHistory }, () => {
            if (chrome.runtime.lastError) {
              console.error('Error saving clipboard item:', chrome.runtime.lastError);
              showToast('Failed to save clipboard!');
              return;
            }
            refreshClipboardHistory(clipboardHistory);
            showToast('Clipboard Item Successfully Added!');
          });
        }
      })
      .catch(err => {
        console.error('Failed to read clipboard contents:', err);
        showToast('Failed to save clipboard!');
      });
  }

  function clearClipboard() {
    const clearModal = document.getElementById('clearConfirmationModal');
    clearModal.style.display = 'block';

    const confirmClearButton = document.getElementById('confirmClear');
    const cancelClearButton = document.getElementById('cancelClear');

    confirmClearButton.addEventListener('click', () => {
      clearModal.style.display = 'none';
      clipboardHistory = [];
      chrome.storage.local.set({ clipboardHistory }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error clearing clipboard history:', chrome.runtime.lastError);
          showToast('Failed to clear clipboard history!');
          return;
        }
        refreshClipboardHistory(clipboardHistory);
        showToast('Clipboard History Cleared!');
      });
    });

    cancelClearButton.addEventListener('click', () => {
      clearModal.style.display = 'none';
    });
  }

  function exportClipboard() {
    downloadClipboardHistory(clipboardHistory);
    showToast('Clipboard History Exported!');
  }

  function downloadClipboardHistory(clipboardHistory) {
    const textContent = clipboardHistory.map(item => {
      const timestamp = new Date(item.timestamp).toLocaleString();
      return `${item.text} [${timestamp}]`;
    }).join("\n");

    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "clipboard_history.txt");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function deleteItem(timestamp) {
    const itemToDelete = clipboardHistory.find(item => item.timestamp === timestamp);
  
    if (itemToDelete.favorite) {
      const modal = document.getElementById('confirmationModal');
      modal.style.display = 'block';
  
      const confirmDeleteButton = document.getElementById('confirmDelete');
      const cancelDeleteButton = document.getElementById('cancelDelete');
  
      confirmDeleteButton.addEventListener('click', () => {
        modal.style.display = 'none';
        performDeletion(timestamp);
      });
  
      cancelDeleteButton.addEventListener('click', () => {
        modal.style.display = 'none';
      });
  
    } else {
      performDeletion(timestamp);
    }
  }

  function performDeletion(timestamp) {
    clipboardHistory = clipboardHistory.filter(item => item.timestamp !== timestamp);
    chrome.storage.local.set({ clipboardHistory }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error deleting clipboard item:', chrome.runtime.lastError);
        showToast('Failed to delete clipboard item!');
        return;
      }
      refreshClipboardHistory(clipboardHistory);
      showToast('Item Deleted!');
    });
  }

  function toggleFavorite(timestamp) {
    clipboardHistory = clipboardHistory.map(item => {
      if (item.timestamp === timestamp) {
        const isFavorite = !item.favorite;
        showToast(isFavorite ? 'Added to Favorites!' : 'Removed from Favorites!');
        return { ...item, favorite: isFavorite };
      }
      return item;
    });
    chrome.storage.local.set({ clipboardHistory }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error toggling favorite status:', chrome.runtime.lastError);
        showToast('Failed to toggle favorite status!');
        return;
      }
      refreshClipboardHistory(clipboardHistory);
    });
  }

  document.addEventListener('DOMContentLoaded', function() {
    const input = document.getElementById('search-input');
    const label = document.getElementById('searchLabel');
    const supportsPlaceholder = CSS.supports('(:placeholder-shown)');
    if (!supportsPlaceholder) {
      input.addEventListener('input', function() {
        if (this.value.length > 0) {
          label.classList.add('float-label');
        } else {
          label.classList.remove('float-label');
        }
      });
    }
  });

  document.addEventListener('keydown', event => {
    if (event.ctrlKey || event.metaKey) {
      if (event.shiftKey) {
        if (event.key.toLowerCase() === 's') {
          setTimeout(saveClipboard, 100);
          event.preventDefault();
        } else if (event.key.toLowerCase() === 'x') {
          clearClipboard();
          event.preventDefault();
        } else if (event.key.toLowerCase() === 'e') {
          exportClipboard();
          event.preventDefault();
        }
      }
    }
  });
});
